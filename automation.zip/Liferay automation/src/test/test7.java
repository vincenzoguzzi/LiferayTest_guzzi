package test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.net.MalformedURLException;
import java.net.URL;

public class test7 {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:/Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String baseUrl = "https://forms.liferay.com/web/forms/shared/-/form/122548";
		 driver.get(baseUrl);
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//div/input")).sendKeys("vincenzo");
		 driver.findElement(By.xpath("//div/input[2]")).click();
		 driver.findElement(By.xpath("//div/input[2]")).sendKeys("06");
		 driver.findElement(By.xpath("//div/input[2]")).sendKeys("09");
		 driver.findElement(By.xpath("//div/input[2]")).sendKeys("1983");
		 driver.findElement(By.xpath("//textarea")).click();
		 driver.findElement(By.xpath("//textarea")).sendKeys("prova test");
	    driver.findElement(By.id("ddm-form-submit")).click();
	    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	
	    {
	        List<WebElement> elements = driver.findElements(By.cssSelector("ddm-form-description"));
	        if (elements.size() > 0) {
	                System.out.println("pass");
	        }
	        else
	                System.out.println("fail");
	        
	      }
	}
}


