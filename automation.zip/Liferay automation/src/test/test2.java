package test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.net.MalformedURLException;
import java.net.URL;

public class test2 {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:/Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String baseUrl = "https://forms.liferay.com/web/forms/shared/-/form/122548";
		 driver.get(baseUrl);
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		    driver.findElement(By.xpath("//div/input")).sendKeys("vincenzo");
	    driver.findElement(By.xpath("//div/input[2]")).click();
	    driver.findElement(By.xpath("//div/input[2]")).sendKeys("ff");
	    String field = driver.findElement(By.xpath("//div/input[2]")).getAttribute("value");
	        int size1 = field.length();
	       
			if (size1 == 0 ) {
				System.out.println("Fail");
			}
				else
					System.out.println("pass");
	  }
	}



